import { useEffect, useState } from "react";
import Header from "../components/Header";
import News from "../components/News";
import getData from "../utils/api-client";

const NewsPage = () => {
  const [news, setNews] = useState([]);
  // const [a, setA] = useState("");
  //  const [b, setB] = useState("");
  // Component life Cycle

  //   const speakNow = () => {
  //     // Check for browser compatibility
  //     const SpeechRecognition =
  //       window.SpeechRecognition || window.webkitSpeechRecognition;
  //     console.log("Speak Now Call ", SpeechRecognition);
  //     if (typeof SpeechRecognition === "undefined") {
  //       console.error("Your browser does not support Speech Recognition.");
  //     } else {
  //       const recognition = new SpeechRecognition();
  //       recognition.continuous = true; // Don't stop listening after a single phrase
  //       recognition.interimResults = true; // Show results as the user speaks
  //       console.log("Params are ");
  //       recognition.onresult = (event) => {
  //         console.log("Event ", event);
  //         let transcript = "";
  //         for (const result of event.results) {
  //           transcript += result[0].transcript;
  //         }
  //         console.log("::::: Transcribed text:", transcript);
  //       };

  //       recognition.onerror = (event) => {
  //         console.error("Speech recognition error detected:", event.error);
  //       };

  //       // Start listening
  //       // recognition.start();
  //       // Remember to add UI controls (e.g., buttons) to start and stop recognition
  //     }
  //   };

  const getHeadLines = async () => {
    const news = await getData(import.meta.env.VITE_APP_NEWS_URL);
    console.log("News ... ", news);
    setNews(news.articles);
  };
  useEffect(() => {
    // Component Mount
    getHeadLines();
    // timer start, interval start, subscribe , api call, localStorage
  }, []);
  //   useEffect(()=>{
  //     // Component Update
  //   })
  //   useEffect(()=>{
  //     // Component Update in a and b change
  //   },[a])
  //   useEffect(()=>{
  //     // Component UnMount
  //     return function(){
  //         //clean up code
  //         // socket close, event close
  //     }
  //   },[])
  return (
    <div>
      <Header />
      <hr />
      {/* <button onClick={speakNow}>Speak Now</button> */}
      {news.map((currentNews, index) => (
        <News
          key={index}
          desc={currentNews.description}
          title={currentNews.title}
          link={currentNews.url}
          image={currentNews.urlToImage}
        />
      ))}
    </div>
  );
};
export default NewsPage;
