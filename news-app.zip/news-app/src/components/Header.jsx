const Header = () => {
  const myStyle = {
    color: "red",
    backgroundColor: "cyan",
    textAlign: "center",
  };
  return (
    <header>
      <h1 style={myStyle}>News App</h1>
    </header>
  );
};
export default Header;
