// Single News
const News = ({ desc, image, link, title }) => {
  return (
    <div>
      <a href={link}>
        <h3>{title}</h3>
      </a>
      <img src={image} style={{ width: "100px", height: "100px" }} />
      <p>{desc}</p>
      <button>Summary</button>
      <p></p>
    </div>
  );
};
export default News;
