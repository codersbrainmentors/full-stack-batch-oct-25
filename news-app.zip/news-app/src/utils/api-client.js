import axios from './axios-config';

const getData = async (URL)=>{
    const response = await axios.get(URL);
    return response.data;
}
export default getData;