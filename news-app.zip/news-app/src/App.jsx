import NewsPage from "./pages/NewsPage";

const App = () => {
  return <NewsPage />;
};
export default App;
