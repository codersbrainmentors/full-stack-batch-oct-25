// Singleton 
// const e = {key: value}
// const taskService = {addTask : function(){}}
// Object ShortHand Style - ES6 
// Handle the Operations on Data 
import Task from './task-model.js';
export const taskService = {
    tasks:[],
    addTask(taskObject){
        // here write the code to add the taskObject
        const task = new Task(taskObject.id ,
             taskObject.name, taskObject.desc, taskObject.doc);
             this.tasks.push(task);
             return task;
             //console.log('Task Added in Array ', this.tasks);
    },
    deleteTask(){

    },
    updateTask(){

    },
    searchTask(){

    },
    sortTask(){

    },
    totalTask(){

    },
    markCount(){

    },
    unMarkCount(){

    },
    toggleTask(){

    }
}