// Controller is a glue b/w view and model
// Controller - Handle View I/O and Talk to Model Layer
import { taskService } from "../models/task-service.js";
window.addEventListener('load', bindEvents);
function bindEvents(){
    document.getElementById('add').addEventListener('click', addTask);
}

function addTask(){
    const fields = ['id', 'name', 'desc', 'doc'];
    const taskObject = {};
    for(let field of fields){
        taskObject[field] = document.getElementById(field).value;
    }
    // const tObject = taskService.addTask(taskObject);
    //  printTask(tObject);
    printTask(taskService.addTask(taskObject));
    
    //console.log(taskObject);

    // DRY
    // const id = document.getElementById('id').value;
    // const name = document.getElementById('name').value;
    // const desc = document.getElementById('desc').value;
    // const doc = document.getElementById('doc').value;
   // console.log('id ', id, ' name ', name, ' desc ', desc, ' doc', doc);

}
function printTask(taskObject){
    // # id
    // . css class
    // [] attribute

    const tbody= document.querySelector('#records');
    const tr = tbody.insertRow();
    for(let key in taskObject){
        const td = tr.insertCell();
        td.innerText = taskObject[key]; 
    }
    

}