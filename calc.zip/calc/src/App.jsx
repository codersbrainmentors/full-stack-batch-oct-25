import Calc from "./pages/Calc";

const App = () => {
  console.log("App Call");
  return <Calc />;
};
export default App;
