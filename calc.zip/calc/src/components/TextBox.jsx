const TextBox = ({ exp, fn }) => {
  console.log("TextBox Call");
  return (
    <div>
      <input
        value={exp}
        onChange={(event) => {
          const val = event.target.value;
          console.log("Value is ", val);
          fn(val);
        }}
        type="text"
        placeholder="Type/Show Expression Here"
      />
    </div>
  );
};
export default TextBox;
