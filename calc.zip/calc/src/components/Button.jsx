const Button = ({ digit, fn }) => {
  console.log("Button Call");
  const buttonClicked = (event) => {
    const buttonValue = event.target.innerText;
    console.log("Button Value is ", buttonValue);
    fn(buttonValue);
  };
  return <button onClick={buttonClicked}>{digit}</button>;
};
export default Button;
