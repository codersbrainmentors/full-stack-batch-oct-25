import { useState } from "react";
import Button from "../components/Button";
import TextBox from "../components/TextBox";

const Calc = () => {
  console.log("Calc Call");
  const [expression, setExpression] = useState("");
  const takeExpression = (expression) => {
    setExpression(expression);
  };
  const giveMeDigit = (digit) => {
    if (digit == "=") {
      setExpression(eval(expression));
    } else {
      console.log("Here i rec ", digit);
      // expression = expression + digit; // Mutable
      setExpression(expression + digit); // Immutable
    }
  };
  return (
    <div>
      <h1>Calculator</h1>
      <TextBox fn={takeExpression} exp={expression} />
      <table>
        <tbody>
          <tr>
            <td>
              <Button digit="9" fn={giveMeDigit} />
            </td>
            <td>
              <Button digit="8" fn={giveMeDigit} />
            </td>
            <td>
              <Button digit="7" fn={giveMeDigit} />
            </td>
            <td>
              <Button digit="+" fn={giveMeDigit} />
            </td>
          </tr>
          <tr>
            <td>
              <Button digit="6" fn={giveMeDigit} />
            </td>
            <td>
              <Button digit="5" fn={giveMeDigit} />
            </td>
            <td>
              <Button digit="4" fn={giveMeDigit} />
            </td>
            <td>
              <Button digit="-" fn={giveMeDigit} />
            </td>
          </tr>
          <tr>
            <td>
              <Button digit="3" fn={giveMeDigit} />
            </td>
            <td>
              <Button digit="2" fn={giveMeDigit} />
            </td>
            <td>
              <Button digit="1" fn={giveMeDigit} />
            </td>
            <td>
              <Button digit="*" fn={giveMeDigit} />
            </td>
          </tr>
          <tr>
            <td>
              <Button digit="/" fn={giveMeDigit} />
            </td>
            <td>
              <Button digit="=" fn={giveMeDigit} />
            </td>
          </tr>
        </tbody>
      </table>

      {/* <Button digit="9" /> // Button({digit:"9"}) */}
      {/* <Button digit="8" fn={giveMeDigit} />
      <Button digit="7" fn={giveMeDigit} /> */}
    </div>
  );
};
export default Calc;
