window.addEventListener('load', bindEvents);
function bindEvents(){
    document.querySelector('#bt')?.addEventListener('click', doCompute);
}
var count:number = 0;
function doCompute(){
    count= count + 5;
    //var e= 100;
    //e = "Hello";
    const span = (document.querySelector('#output')) as HTMLElement;
    span.innerText = count.toString();
}