var a:any;
var b:boolean;
