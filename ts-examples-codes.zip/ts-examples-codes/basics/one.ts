var a:number = 100;
var b:number = 200;
var c = a + b;
console.log("Sum is "+c);

function add(x:number, y:number){
    return x + y;
}

var arr:string[] = ["A", "B", "C"];
