var x:number; // explicit
var y = 100; // implicit
// Primitive Data Type
var z:string;
var n = "Amit";
var b:boolean;
var hh:bigint;
var hh2:Symbol;
var d = true;
var n3:string | null;
var n1:undefined ;
var n2 = undefined;

// Implicit Any - Very Bad
var b9 =[];

var g1 ;

// Array
var bb:string[] = ["A", "B","C"];

// Union 
var e : number | undefined;
e = undefined;
e = 100;
//e = "AMit"; // error


// any - bad
var h:any ;
h = "AA";
h = 1000;
var a5:any;
var b5:boolean ; 
console.log(h.toUpperCase()); // TypeError
h = true;
// better than any - use unknown
var h2:unknown;
h2 = "Abcd";
// console.log(h2.toLowerCase());
if(typeof h2 ==='string'){
console.log(h2.toUpperCase());
}
h2= 100.777676575;
if(typeof h2 ==='number')
{
    console.log(h2.toPrecision(2))
}

h2 = true;

function show():void{

}

function disp(x:number , y:string):void{

}
function output(x:number, y:number):string{
    return "";
}

function crashIt():never{
    throw new Error("Some Business Wrapped Error Crash....");
}

try{
    // DB Connection
}
catch(err){
    crashIt();
}

// Complex Type
type Employee = {
    id:number;
    name:string;
    city?:string;
}
function dispEmp(obj:Employee|null){

}
let ram:Employee|null = null;
ram = {id:1001, name:'Ram', city:'Delhi'};
//const ram:Employee|null = {id:1001 , name:'Ram', city:'Delhi'};
dispEmp(ram);
const shyam:Employee= {id:777, name:'Shyam'};
// const ram:{id:number, name:string, city:string} = {id:1001, name:'Ram', city:'Delhi'};
// const shyam:{id:number, name:string, city:string} = {id:1001, ename:'Ramesh', city:'Delhi', phone:111111};

const prices:number[] = [10,20,30]; // Array
const contact:[number, string , number] = [1001, 'A',111]; // Tuples
console.log(contact[0], contact[1], contact[2])

