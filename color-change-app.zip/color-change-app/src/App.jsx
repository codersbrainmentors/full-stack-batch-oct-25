import ColorChangeApp from "./pages/ColorChangeApp";

const App = () => {
  return <ColorChangeApp title="Color Change App..." />;
};
export default App;
