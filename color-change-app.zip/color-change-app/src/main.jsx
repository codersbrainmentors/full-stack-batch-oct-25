// VDOM Convert DOM by Using ReactDOM
import { createRoot } from "react-dom/client";
import App from "./App";
const div = document.querySelector("#root");

createRoot(div).render(<App />);
