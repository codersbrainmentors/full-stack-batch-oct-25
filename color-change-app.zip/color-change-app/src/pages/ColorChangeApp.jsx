import ColorPicker from "../components/ColorPicker";
import ShowColor from "../components/ShowColor";
import { useState } from "react";
// import React from 'react';
const ColorChangeApp = (props) => {
  // Hooks
  //React.useState();

  const [color, setColor] = useState("#e33838ff");
  const myStyle = {
    color: "orange",
    backgroundColor: "black",
    height: "500px",
  };
  const giveMeTheColorCode = (colorCode) => {
    console.log(
      " I am the Parent i get the ColorCode from the Child ",
      colorCode
    );
    setColor(colorCode); // Re-render the current component
  };
  return (
    <div style={myStyle}>
      <h1>{props.title}</h1>
      <ColorPicker lbl="Choose Your Color" fn={giveMeTheColorCode} />
      <br />
      <hr />
      <br />
      <ShowColor color={color} />
    </div>
  );
};
export default ColorChangeApp;
