const ColorPicker = ({ lbl, fn }) => {
  const colorPicked = (event) => {
    const colorCode = event.target.value;
    console.log("Color Picked Call...", colorCode);
    fn(colorCode); // giveMeTheColorCode(colorCode)
  };
  return (
    <div>
      <label>{lbl}</label>
      <input type="color" onChange={colorPicked} />
    </div>
  );
};
export default ColorPicker;
