const ShowColor = ({ color }) => {
  return (
    <div>
      <fieldset style={{ backgroundColor: color, height: "200px" }}>
        <legend>Showing Colors</legend>
        <h3>Welcome User</h3>
      </fieldset>
    </div>
  );
};

export default ShowColor;
