// Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-analytics.js";
  import { getFirestore } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-firestore.js"
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyC6vXvS9dt4ehEXvia3HKWa0XI_bL5BhOc",
    authDomain: "task-app-4b776.firebaseapp.com",
    projectId: "task-app-4b776",
    storageBucket: "task-app-4b776.firebasestorage.app",
    messagingSenderId: "156446688628",
    appId: "1:156446688628:web:2788ac8c97215220039821",
    measurementId: "G-1F6ZBYQX48"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  export const db = getFirestore(app);
  const analytics = getAnalytics(app);