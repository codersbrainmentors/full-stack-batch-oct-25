// Controller is a glue b/w view and model
// Controller - Handle View I/O and Talk to Model Layer
import { taskService } from "../models/task-service.js";
import { storeToDB } from "../utils/crud.js";
window.addEventListener('load', init);

function init(){
    bindEvents();
    updateCounts();
    disableButtons();
}

function disableButtons(){
    document.querySelector('#remove').disabled = true;
     document.querySelector('#update').disabled = true;
    
}

function bindEvents(){
    document.getElementById('add').addEventListener('click', addTask);
    document.querySelector('#remove').addEventListener('click', deleteForEver);
    document.querySelector('#update').addEventListener('click', updateTask);
    document.querySelector('#save').addEventListener('click', saveTask);
    document.querySelector('#load').addEventListener('click', loadTask);
    document.querySelector('#savetodb').addEventListener('click', saveToDb);
}
function saveToDb(){
    taskService.tasks.forEach(taskObject=>storeToDB(taskObject));
    alert("Data Store in DB");
}

function saveTask(){
    if(window.localStorage){
        localStorage.tasks =  JSON.stringify({alltask: taskService.getAllTask()});
        alert("Data Saved...")
    }
    else{
        alert("outdated Browser...");
    }
}

function loadTask(){
    if(window.localStorage){
        if(localStorage.tasks){
            taskService.tasks = JSON.parse(localStorage.tasks).alltask;
            console.log('All Task ', typeof taskService.tasks, ' ', taskService.tasks);
            printTasks(taskService.tasks);
            updateCounts();
            alert("Loaded...");
        }
        else{
            alert("Nothing to Load...");
        }
    }
    else{
        alert("Outdated Browser...");
    }
}

function updateTask(){
    const tObject = readFields();
    for(let key in tObject){
        taskObjectForUpdate[key] = tObject[key];
    }
    printTasks(taskService.getAllTask());


}

function deleteForEver(){
    taskService.deleteTask();
    updateCounts();
    
    printTasks(taskService.getAllTask());
    disableButtons();
}

function updateCounts(){
    document.querySelector('#total-records').innerText = taskService.totalTask();
    document.querySelector('#mark-records').innerText = taskService.markCount();
    document.querySelector('#unmark-records').innerText = taskService.unMarkCount();
}

function readFields(){
     const fields = ['id', 'name', 'desc', 'doc'];
    const taskObject = {};
    for(let field of fields){
        taskObject[field] = document.getElementById(field).value;
    }
    return taskObject;
}

function addTask(){
   const taskObject =readFields();
    // const tObject = taskService.addTask(taskObject);
    //  printTask(tObject);
    printTask(taskService.addTask(taskObject));
    updateCounts();
    //console.log(taskObject);

    // DRY
    // const id = document.getElementById('id').value;
    // const name = document.getElementById('name').value;
    // const desc = document.getElementById('desc').value;
    // const doc = document.getElementById('doc').value;
   // console.log('id ', id, ' name ', name, ' desc ', desc, ' doc', doc);

}

function createIcon(className, fn, taskId){
    // <i class="fa-solid fa-trash"></i>
    //return `<i onClick = "" class="fa-solid fa-pen-to-square"></i>`;
    const icon = document.createElement('i'); // <i> </i>
    icon.className = 'hand fa-solid '+className; // <i class="fa-solid fa-pen-to-square"></i>
    icon.addEventListener('click', fn);
    icon.setAttribute('task-id', taskId); // custom attribute
    return icon;
}

function printTasks(allTask){
    document.querySelector('#records').innerHTML = '';
    allTask.forEach(taskObject=>printTask(taskObject));
}

function printTask(taskObject){
    // # id
    // . css class
    // [] attribute

    const tbody= document.querySelector('#records');
    const tr = tbody.insertRow();
    for(let key in taskObject){
        if(key == 'isDeleted'){
            continue;
        }
        const td = tr.insertCell();
        td.innerText = taskObject[key]; 
    }
    const oprCell =tr.insertCell();
    oprCell.appendChild(createIcon('fa-pen-to-square', edit, taskObject.id));
    oprCell.appendChild(createIcon('fa-trash', toggleDelete, taskObject.id));
    

}
let taskObjectForUpdate ; 
function edit(){
   
    console.log('Edit Call', this);
    const id = this.getAttribute('task-id');
    taskObjectForUpdate = taskService.searchTaskById(id);
    for(let key in taskObjectForUpdate){
        if(key =='status' || key =='isDeleted'){
            continue;
        }
       document.querySelector('#'+key).value =  taskObjectForUpdate[key];
    }
    document.querySelector('#update').disabled = false;
}
function toggleDelete(){
    const currentIcon = this;
    const taskId = currentIcon.getAttribute('task-id');
    taskService.toggleTask(taskId);
   
    const tr = currentIcon.parentNode.parentNode;
    //tr.className = 'red';
    tr.classList.toggle('red');
     updateCounts();
     if(taskService.markCount()>0){
     document.querySelector('#remove').disabled = false;
     }
     else{
        disableButtons();
     }
    console.log('Toggle Delete Call ', tr);
}