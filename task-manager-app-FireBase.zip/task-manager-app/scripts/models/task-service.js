// Singleton 
// const e = {key: value}
// const taskService = {addTask : function(){}}
// Object ShortHand Style - ES6 
// Handle the Operations on Data 
import Task from './task-model.js';
export const taskService = {
    tasks:[],
    addTask(taskObject){
        // here write the code to add the taskObject
        const task = new Task(taskObject.id ,
             taskObject.name, taskObject.desc, taskObject.doc);
             this.tasks.push(task);
             return task;
             //console.log('Task Added in Array ', this.tasks);
    },
    getAllTask(){
        return this.tasks;
    },
    deleteTask(){
        this.tasks = this.tasks.filter(taskObject => !taskObject.isDeleted);
    },
    updateTask(){

    },
    searchTaskById(taskId){
        return this.tasks.find(taskObject=>taskObject.id == taskId);
    },
    sortTask(){

    },
    totalTask(){
        return this.tasks.length;
    },
    markCount(){
        return this.tasks.filter(taskObject=>taskObject.isDeleted).length;
    },
    unMarkCount(){
        return this.tasks.length - this.markCount();
    },
    toggleTask(taskId){
        const taskObject = this.searchTaskById(taskId);
        if(taskObject){
            taskObject.isDeleted = !taskObject.isDeleted;
        }
    }
}