var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var P = /** @class */ (function () {
    function P() {
        this.x = 100;
        this.y = 200;
        this.z = 999;
    }
    Object.defineProperty(P.prototype, "Y", {
        get: function () {
            return this.y;
        },
        enumerable: false,
        configurable: true
    });
    P.prototype.show = function () {
        console.log("I am the P Class Show...");
    };
    P.prototype.output = function () {
        console.log("I am the P Output...");
    };
    return P;
}());
var C = /** @class */ (function (_super) {
    __extends(C, _super);
    function C() {
        var _this = _super.call(this) || this;
        _this.x = 200;
        return _this;
    }
    C.prototype.show = function () {
        _super.prototype.show.call(this);
        var result = this.x + this.Y + this.z;
        console.log("I am the C Class Show..." + result);
    };
    C.prototype.print = function () {
        console.log("I am the child print...");
    };
    return C;
}(P));
//let c1:C = new C();
var c1 = new C(); // Upcasting
c1.show();
c1.output();
//c1.print();
