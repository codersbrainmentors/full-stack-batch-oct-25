class P{
    x:number; // public
    private y:number;
    protected z:number;
    get Y(){
        return this.y;
    }
    constructor(){
        this.x = 100;
        this.y = 200;
        this.z = 999;
    }
    show():void{
        console.log("I am the P Class Show...");
    }
    output():void{
        console.log("I am the P Output...")
    }
}
class C extends P{
    x:number;
    constructor(){
        super(); 
        this.x = 200;
    }
     show():void{
        super.show();
        let result = this.x + this.Y + this.z;
        console.log("I am the C Class Show..."+result);
    }
    print():void{
        console.log("I am the child print...");
    }
}

//let c1:C = new C();
let c1:P = new C(); // Upcasting
c1.show();
c1.output();
let c2:C = c1 as C; // Downcasting
//c1.print();
c2.print();