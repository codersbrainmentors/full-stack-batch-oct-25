// class name - NOUN
// object - pronoun
// Methods - verb
// Class Relationships
// a) IS-A 
// b) HAS-A - object create and use.
class Customer{
    // order:Order = new Order(); // Has-A (Composition)
    constructor(private order:Order){ // Aggregation
        order.show();
        order.dontShow();
    }
}
// IS-A - Generalization & Specialization
class CashCustomer extends Customer{

}
class Order{
    show():void{

    }
    dontShow():void{

    }
}
class CreditCustomer extends Customer {

}
let order:Order = new Order(); // 
let customer:Customer|null = new Customer(order);
customer = null;
