class Employee{
    // Data Members
    // Instance Members of class 
    private id:number; // default scope of instance member is public
    private _name: string;
    public get name(): string {
        return this._name;
    }
    public set name(value: string) {
        this._name = value;
    }
    protected salary:number; 
    readonly companyName:string;
    constructor(id:number, name:string, salary:number=1000){
        this.id = id;
        this._name = name;
        this.salary = salary;
        this.companyName = "Brain Mentors";
    }  
    public show():void{
        console.log(`Id is ${this.id} Name ${this.name} Salary ${this.salary}`);
    }
    set ID(id:number){
        if(id<=0){
            console.log("Invalid id ", id);
            return ; 
        }
        this.id = id;
    }
    get ID(){
        return this.id;
    }
}
let obj:Employee = new Employee(1001, 'Ram', 2222);

obj.name = 'Ramesh';
obj.ID = -1002;
console.log('ID is ', obj.ID);
//obj.companyName = "ABCD";
// obj.id = 10001;
obj.show();
