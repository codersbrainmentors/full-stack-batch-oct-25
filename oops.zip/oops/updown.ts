abstract class Account{
    id:number;
    name:string;
    constructor(id:number, name:string){
        this.id = id;
        this.name = name;
    }
    showBalance():void{
        console.log('Balance is ');
    }
    abstract roi():void;
}
class SavingAccount extends Account{
    roi():void{
        console.log("rec roi 4%");
    }
    limit():void{
        console.log("Limit Trans");
    }
}
class CurrentAccount extends Account{
    roi():void{
        console.log("pay roi 5%");
    }
    od():void{
        console.log("OD Limit");
    }
}
class FDAccount extends Account{
    roi():void{
        console.log("pay roi 7%");
    }
    locking():void{
        console.log("Money Lock for 1 year...");
    }
}

class Caller{
    static callMe(account:Account):void{
         account.roi();
    account.showBalance();
    if(account instanceof SavingAccount){
        (account as SavingAccount).limit();
    }
    else if(account instanceof CurrentAccount){
        (account as CurrentAccount).od();
    }
    else{
        (account as FDAccount).locking();
    }
    
    }
}
Caller.callMe(new SavingAccount(1001, "SA"));
Caller.callMe(new CurrentAccount(1002, "CA"));
Caller.callMe(new FDAccount(1003, "FD"));



// var sa:SavingAccount = new SavingAccount(1001, "SA");
// sa.roi();
// sa.showBalance();
// sa.limit();
// var ca:CurrentAccount = new CurrentAccount(1001, "CA");
// ca.roi();
// ca.showBalance();
// ca.od();
// var fd:FDAccount = new FDAccount(1002, "FD");
// fd.roi();
// fd.showBalance();
// fd.locking();
