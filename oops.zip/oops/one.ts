var a = 10;
var b:number = 10; // Bad Way

var c:number;

function getTotal(x:number){
    return x * 20;
}

var d:string | undefined; // union
d = undefined;
d = "Amit";

let image:string | null;
image = null;

let token:string | undefined;

function show():void{
    return undefined;
    
}


show();

// API CALLS
let response:unknown;
response ={id:1001};
response = "Amit";
if(typeof response ==='string'){
response.toUpperCase();
}




function crash():never{
    
    throw new Error("Something went wrong...");

}
function doPayment(value:string){
    if(value ==='success'){
        console.log('Success');
    }
    else if(value ==='fail'){
         console.log('Fail');
    }
    else if(value === 'pending'){
 console.log('Pending');
    }
    else{
        crash();
    }
}

type paymentValue = "success"|"fail"|"pending"|"ABCD";
var p : paymentValue = "ABCD";
doPayment(p);

// Intersection 
type Roles = {name:string | undefined, desc:string};
type Rights = {status:string};
type Groups = {gname:string};
type Auth = Roles & Rights | Groups;
let user:Auth = {name:"Admin", desc:"Admin User", status:"Active"};