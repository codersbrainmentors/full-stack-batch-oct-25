class A{
    // Constructor ShortHand
    constructor(private x:number, private y:number){

    }
    show():void{
        console.log(this.x, this.y);
    }
}
let obj2:A = new A(10,20);
obj2.show();