// Bridge File - Connect VDOM to DOM using ReactDOM
import { createRoot } from "react-dom/client";
import App from "./App";
// dom
const rootDiv = document.querySelector("#root");

// <App/> - VDOM
createRoot(rootDiv).render(<App />); // VDOM --> DOM
