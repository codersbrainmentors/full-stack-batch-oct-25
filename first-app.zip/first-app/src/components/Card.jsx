// export const Card = (props) => {
export const Card = ({ prod }) => {
  return (
    <>
      {/* {props.prod.map((product, index) => ( */}
      {prod.map((product, index) => (
        // <div className="box" key={index}>
        <div className="box" key={product.id}>
          <h1>
            {index + 1} {product.name}
          </h1>
          {index % 2 == 0 ? (
            <h2 style={{ color: "orange" }}>{product.desc}</h2>
          ) : (
            <h3>{product.desc}</h3>
          )}
        </div>
      ))}
    </>
  );
};
