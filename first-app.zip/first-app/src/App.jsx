// Component - Root Component / First Component
// It is just a function - Having JSX
// React - ES6 Arrow Function - Pure Function
import "./App.css";
import React from "react";
import { Card } from "./components/Card";
const App = () => {
  const name = "Amit";
  const myStyle = {
    color: "red",
    backgroundColor: "yellow",
  };
  const products = [
    { id: 1001, name: "Apple Iphone", desc: "Iphone 17" },
    { id: 1002, name: "Samsung", desc: "Fold 7" },
  ];
  const errorFlag = true;
  return (
    <>
      {errorFlag && (
        <p style={{ color: "red" }}>Password cant be less than 8 chars</p>
      )}
      <Card prod={products} />
    </>
  );

  // return React.createElement(
  //   "div",
  //   { className: "box" },
  //   React.createElement(
  //     "h1",
  //     { style: { color: "orange", backgroundColor: "yellow" } },
  //     "Hello React",
  //     name,
  //     name.toUpperCase(),
  //     10 + 20 - 3
  //   )
  // );

  // //return; //(

  // // <h1 style={myStyle}>
  // // <div className="box">
  // //   <h1 style={{ color: "red", backgroundColor: "green" }}>
  // //     Hello React {name} {10 + 30 - 2} {name.toUpperCase()}
  // //   </h1>
  // // </div>
  // //);
};
export default App;
